import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  Diamond,
  Gem,
  Globe2,
  Heart,
  Camera,
  Mail,
  Menu,
  MessageCircle,
  Minus,
  PackageCheck,
  Play,
  Plus,
  Search,
  Send,
  ShieldCheck,
  ShoppingBag,
  Trash2,
  Truck,
  UserRound,
  X,
} from "lucide-react";

type CategoryId = "ring" | "necklace" | "earrings" | "bracelet" | "chain" | "gold";

type Product = {
  id: string;
  name: string;
  category: CategoryId;
  image: string;
  weight: string;
  making: string;
  price: number;
  description: string;
  new?: boolean;
};

type CartItem = { id: string; quantity: number };

type Article = {
  id: number;
  title: string;
  category: string;
  date: string;
  image: string;
  intro: string;
};

const categories: { id: CategoryId; name: string; image: string; position?: string }[] = [
  { id: "ring", name: "انگشتر", image: "/images/dark-ring.jpg", position: "48% center" },
  {
    id: "necklace",
    name: "گردنبند",
    image: "https://images.pexels.com/photos/27779424/pexels-photo-27779424.jpeg?auto=compress&cs=tinysrgb&w=800&h=1200&fit=crop",
    position: "center 48%",
  },
  {
    id: "earrings",
    name: "گوشواره",
    image: "https://images.pexels.com/photos/32797480/pexels-photo-32797480.jpeg?auto=compress&cs=tinysrgb&w=800&h=1200&fit=crop",
  },
  {
    id: "bracelet",
    name: "دستبند",
    image: "https://images.pexels.com/photos/10341191/pexels-photo-10341191.jpeg?auto=compress&cs=tinysrgb&w=800&h=1200&fit=crop",
    position: "center 56%",
  },
  {
    id: "chain",
    name: "زنجیر",
    image: "https://images.pexels.com/photos/36136152/pexels-photo-36136152.jpeg?auto=compress&cs=tinysrgb&w=800&h=1200&fit=crop",
  },
  { id: "gold", name: "شمش طلا", image: "/images/gold-bars.jpg" },
];

const products: Product[] = [
  {
    id: "mira-bracelet",
    name: "دستبند میرا",
    category: "bracelet",
    image: "/images/product-bracelet.jpg",
    weight: "4.28 g",
    making: "7%",
    price: 27800000,
    description: "دستبندی ظریف از طلای ۱۸ عیار با نگین های درخشان؛ برای همراهی هر روز و هر لحظه خاص.",
  },
  {
    id: "serin-earrings",
    name: "گوشواره سرین",
    category: "earrings",
    image: "/images/product-earrings.jpg",
    weight: "2.16 g",
    making: "9%",
    price: 17250000,
    description: "گوشواره های آویز با درخشش لطیف نگین و فرم کلاسیک، ساخته شده از طلای ۱۸ عیار.",
    new: true,
  },
  {
    id: "nova-necklace",
    name: "گردنبند نوا",
    category: "necklace",
    image: "/images/product-necklace.jpg",
    weight: "3.12 g",
    making: "8.5%",
    price: 15670000,
    description: "آویزی مینیمال و ماندگار بر زنجیری ظریف از طلای ۱۸ عیار؛ زیبایی در ساده ترین شکل خود.",
  },
  {
    id: "aroya-ring",
    name: "انگشتر آرویا",
    category: "ring",
    image: "/images/product-ring.jpg",
    weight: "2.84 g",
    making: "7.5%",
    price: 12840000,
    description: "انگشتری از طلای ۱۸ عیار با نگین مرکزی چشمگیر و پرداختی دقیق برای درخششی همیشگی.",
    new: true,
  },
  {
    id: "elara-chain",
    name: "زنجیر الارا",
    category: "chain",
    image: "/images/product-necklace.jpg",
    weight: "3.45 g",
    making: "6%",
    price: 14680000,
    description: "زنجیری خوش تراش و سبک از طلای ۱۸ عیار، مناسب برای استفاده به تنهایی یا همراه آویز.",
  },
  {
    id: "nova-gold-bar",
    name: "شمش طلای نوا",
    category: "gold",
    image: "/images/gold-bars.jpg",
    weight: "5.00 g",
    making: "0%",
    price: 32500000,
    description: "شمش طلای استاندارد ۱۸ عیار، انتخابی ارزشمند برای هدیه یا سرمایه گذاری.",
  },
];

const heroSlides = [
  {
    image: "/images/hero-model.jpg",
    title: ["Timeless", "Elegance"],
    description: "زیبایی ماندگار، برای ویترین شما",
    darkText: false,
    position: "center center",
  },
  {
    image: "/images/hero-still-life.jpg",
    title: ["Gold,", "Curated."],
    description: "انتخابی دقیق برای درخششی که دیده می شود.",
    darkText: true,
    position: "center center",
  },
  {
    image: "/images/hero-jewels.jpg",
    title: ["A Lasting", "Brilliance."],
    description: "جزئیاتی برای لحظه های ماندگار شما",
    darkText: true,
    position: "center center",
  },
];

const collectionSlides = [
  {
    image: "/images/collection-ring.jpg",
    eyebrow: "NEW COLLECTION",
    title: "کالکشن جدید نوا",
    description: "مجموعه ای از طراحی های خاص و منحصربه فرد، برای کسانی که به جزئیات اهمیت می دهند.",
  },
  {
    image: "/images/hero-jewels.jpg",
    eyebrow: "THE SIGNATURE EDIT",
    title: "درخشش هر روز",
    description: "طراحی هایی ظریف و ماندگار که زیبایی لحظه های ساده را کامل می کنند.",
  },
  {
    image: "/images/hero-still-life.jpg",
    eyebrow: "NOVA GOLD",
    title: "روایتی از طلا",
    description: "ترکیبی از هنر، اصالت و ظرافت برای سلیقه های متفاوت.",
  },
];

const articles: Article[] = [
  {
    id: 1,
    title: "۵ اشتباه رایج در خرید عمده طلا",
    category: "تجارت و کسب و کار",
    date: "۱۰ اردیبهشت ۱۴۰۴",
    image: "https://images.pexels.com/photos/7167019/pexels-photo-7167019.jpeg?auto=compress&cs=tinysrgb&w=1100&h=650&fit=crop",
    intro: "خرید هوشمندانه طلا از شناخت عیار، اجرت ساخت و انتخاب یک همراه قابل اعتماد آغاز می شود. در این راهنما به نکاتی می پردازیم که به تصمیم گیری مطمئن تر کمک می کنند.",
  },
  {
    id: 2,
    title: "راهنمای انتخاب محصولات کم اجرت",
    category: "خرید عمده",
    date: "۱۸ فروردین ۱۴۰۴",
    image: "https://images.pexels.com/photos/9405809/pexels-photo-9405809.jpeg?auto=compress&cs=tinysrgb&w=1100&h=650&fit=crop",
    intro: "در انتخاب زیورآلات، زیبایی تنها معیار نیست. وزن، شیوه ساخت و جزئیات پرداخت در ارزش نهایی هر قطعه نقش مهمی دارند.",
  },
  {
    id: 3,
    title: "چطور ویترین طلافروشی را بچینیم؟",
    category: "مدیریت فروش",
    date: "۲۵ فروردین ۱۴۰۴",
    image: "https://images.pexels.com/photos/20858959/pexels-photo-20858959.jpeg?auto=compress&cs=tinysrgb&w=1100&h=650&fit=crop",
    intro: "یک ویترین خوب داستانی روشن روایت می کند. با نور مناسب، فاصله گذاری درست و انتخاب مجموعه ای هماهنگ، هر قطعه فرصت دیده شدن پیدا می کند.",
  },
  {
    id: 4,
    title: "نگهداری از زیورآلات طلای ظریف",
    category: "راهنمای نگهداری",
    date: "۰۸ اسفند ۱۴۰۳",
    image: "/images/hero-jewels.jpg",
    intro: "با چند عادت ساده می توان درخشش طلا و نگین ها را برای سال های طولانی حفظ کرد؛ از نگهداری جداگانه تا تمیز کردن ملایم.",
  },
  {
    id: 5,
    title: "طلا، هدیه ای برای همیشه",
    category: "سبک زندگی",
    date: "۲۲ بهمن ۱۴۰۳",
    image: "/images/collection-ring.jpg",
    intro: "بعضی هدیه ها فراتر از یک لحظه می مانند. قطعه ای از طلا می تواند یادآور یک خاطره، یک شروع و یک انتخاب شخصی باشد.",
  },
  {
    id: 6,
    title: "راز درخشش یک مجموعه هماهنگ",
    category: "استایل و زیبایی",
    date: "۱۲ بهمن ۱۴۰۳",
    image: "/images/hero-model.jpg",
    intro: "هماهنگ کردن گردنبند، گوشواره و انگشتر به معنی یکسان بودن آنها نیست؛ تعادل در فرم و رنگ، زیبایی طبیعی تری می سازد.",
  },
];

const formatPrice = (price: number) => new Intl.NumberFormat("en-US").format(price);

function Brand({ inverse = false, onClick }: { inverse?: boolean; onClick?: () => void }) {
  return (
    <a className={`brand ${inverse ? "brand--inverse" : ""}`} href="#top" onClick={onClick} aria-label="NOVA GOLD - صفحه اصلی">
      <span>NOVA</span>
      <small>GOLD</small>
    </a>
  );
}

function Reveal({ children, className = "", delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const reducedMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={reducedMotion ? false : { opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.13 }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

function Dialog({ children, onClose, label, className = "" }: { children: ReactNode; onClose: () => void; label: string; className?: string }) {
  return (
    <motion.div
      className="screen-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <motion.div
        className={`dialog ${className}`}
        role="dialog"
        aria-modal="true"
        aria-label={label}
        initial={{ opacity: 0, y: 24, scale: 0.985 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 16, scale: 0.985 }}
        transition={{ duration: 0.28 }}
      >
        <button className="dialog-close icon-button" type="button" onClick={onClose} aria-label="بستن">
          <X size={21} strokeWidth={1.6} />
        </button>
        {children}
      </motion.div>
    </motion.div>
  );
}

export default function App() {
  const [heroIndex, setHeroIndex] = useState(0);
  const [collectionIndex, setCollectionIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<CategoryId | null>(null);
  const [showAllProducts, setShowAllProducts] = useState(false);
  const [showAllArticles, setShowAllArticles] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [storyOpen, setStoryOpen] = useState(false);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [activeArticle, setActiveArticle] = useState<Article | null>(null);
  const [productQuantity, setProductQuantity] = useState(1);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("nova-cart") || "[]") as CartItem[];
    } catch {
      return [];
    }
  });
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("nova-favorites") || "[]") as string[];
    } catch {
      return [];
    }
  });
  const [profile, setProfile] = useState<{ name: string; email: string }>(() => {
    try {
      return JSON.parse(localStorage.getItem("nova-profile") || '{"name":"","email":"}') as { name: string; email: string };
    } catch {
      return { name: "", email: "" };
    }
  });
  const [profileName, setProfileName] = useState(profile.name);
  const [profileEmail, setProfileEmail] = useState(profile.email);
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [footerEmail, setFooterEmail] = useState("");
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);
  const [footerSuccess, setFooterSuccess] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => localStorage.setItem("nova-cart", JSON.stringify(cart)), [cart]);
  useEffect(() => localStorage.setItem("nova-favorites", JSON.stringify(favorites)), [favorites]);

  useEffect(() => {
    const hasOverlay = mobileMenuOpen || cartOpen || accountOpen || storyOpen || Boolean(activeProduct) || Boolean(activeArticle);
    document.body.classList.toggle("has-overlay", hasOverlay);
    return () => document.body.classList.remove("has-overlay");
  }, [mobileMenuOpen, cartOpen, accountOpen, storyOpen, activeProduct, activeArticle]);

  useEffect(() => {
    const onEscape = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setSearchOpen(false);
      setMobileMenuOpen(false);
      setCartOpen(false);
      setAccountOpen(false);
      setStoryOpen(false);
      setActiveProduct(null);
      setActiveArticle(null);
    };
    window.addEventListener("keydown", onEscape);
    return () => window.removeEventListener("keydown", onEscape);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 3000);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const visibleProducts = selectedCategory
    ? products.filter((product) => product.category === selectedCategory)
    : showAllProducts
      ? products
      : products.slice(0, 4);
  const searchResults = products.filter((product) =>
    `${product.name} ${categories.find((category) => category.id === product.category)?.name}`.includes(searchTerm.trim()),
  );
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartTotal = useMemo(
    () => cart.reduce((total, item) => total + (products.find((product) => product.id === item.id)?.price || 0) * item.quantity, 0),
    [cart],
  );

  const selectCategory = (category: CategoryId | null, showAll = false) => {
    setSelectedCategory(category);
    setShowAllProducts(Boolean(category) || showAll);
    setMobileMenuOpen(false);
    window.setTimeout(() => document.getElementById("products")?.scrollIntoView({ behavior: "smooth" }), 30);
  };

  const openProduct = (product: Product) => {
    setProductQuantity(1);
    setActiveProduct(product);
    setSearchOpen(false);
  };

  const toggleFavorite = (id: string) => {
    const wasFavorite = favorites.includes(id);
    setFavorites((current) => (wasFavorite ? current.filter((favorite) => favorite !== id) : [...current, id]));
    setToast(wasFavorite ? "از علاقه مندی ها حذف شد" : "به علاقه مندی ها اضافه شد");
  };

  const addToCart = (id: string, quantity = 1) => {
    setCart((current) => {
      const existing = current.find((item) => item.id === id);
      return existing
        ? current.map((item) => (item.id === id ? { ...item, quantity: item.quantity + quantity } : item))
        : [...current, { id, quantity }];
    });
    setActiveProduct(null);
    setCartOpen(true);
  };

  const updateCartQuantity = (id: string, change: number) => {
    setCart((current) =>
      current.map((item) => (item.id === id ? { ...item, quantity: Math.max(0, item.quantity + change) } : item)).filter((item) => item.quantity > 0),
    );
  };

  const subscribe = (event: FormEvent<HTMLFormElement>, source: "main" | "footer") => {
    event.preventDefault();
    const email = source === "main" ? newsletterEmail : footerEmail;
    if (!email.trim()) return;
    const saved = JSON.parse(localStorage.getItem("nova-newsletter") || "[]") as string[];
    if (!saved.includes(email.trim())) localStorage.setItem("nova-newsletter", JSON.stringify([...saved, email.trim()]));
    if (source === "main") setNewsletterSuccess(true);
    else setFooterSuccess(true);
  };

  const saveProfile = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextProfile = { name: profileName.trim(), email: profileEmail.trim() };
    setProfile(nextProfile);
    localStorage.setItem("nova-profile", JSON.stringify(nextProfile));
    setAccountOpen(false);
    setToast(`خوش آمدید، ${nextProfile.name}`);
  };

  const checkoutByEmail = () => {
    const lines = cart.map((item) => {
      const product = products.find((entry) => entry.id === item.id);
      return `${product?.name || item.id} × ${item.quantity}`;
    });
    const subject = encodeURIComponent("درخواست سفارش از NOVA GOLD");
    const body = encodeURIComponent(`سلام، برای سفارش این محصولات راهنمایی می خواهم:\n\n${lines.join("\n")}\n\nجمع تقریبی: ${formatPrice(cartTotal)} تومان`);
    window.location.href = `mailto:orders@novagold.com?subject=${subject}&body=${body}`;
  };

  const currentHero = heroSlides[heroIndex];
  const currentCollection = collectionSlides[collectionIndex];

  return (
    <div id="top" className="site-shell">
      <div className="utility-bar">
        <div className="page-container utility-inner">
          <div className="utility-locale">
            <Globe2 size={13} strokeWidth={1.5} />
            <span>FA</span>
            <ChevronDown size={11} strokeWidth={1.4} />
            <span className="utility-divider" />
            <span dir="rtl">ریال</span>
          </div>
          <div className="utility-links" dir="rtl">
            <span><Truck size={13} strokeWidth={1.5} /> ارسال رایگان به سراسر کشور</span>
            <span>ویژه عمده</span>
            <span>خرید از کشور</span>
          </div>
        </div>
      </div>

      <header className="site-header">
        <div className="page-container header-inner">
          <button className="icon-button mobile-menu-button" type="button" onClick={() => setMobileMenuOpen(true)} aria-label="باز کردن منو">
            <Menu size={24} strokeWidth={1.45} />
          </button>
          <nav className="desktop-nav" dir="rtl" aria-label="منوی اصلی">
            <a href="#top">خانه</a>
            <a href="#products">محصولات</a>
            <a href="#categories">دسته بندی</a>
            <a href="#collection">کالکشن ها</a>
            <a href="#journal">مجله</a>
            <a href="#about">درباره ما</a>
            <a href="#newsletter">تماس با ما</a>
          </nav>
          <Brand />
          <div className="header-actions">
            <button className="icon-button" type="button" onClick={() => setSearchOpen((value) => !value)} aria-label="جستجوی محصولات" aria-expanded={searchOpen}>
              <Search size={24} strokeWidth={1.4} />
            </button>
            <button className="icon-button account-trigger" type="button" onClick={() => setAccountOpen(true)} aria-label="حساب کاربری">
              <UserRound size={24} strokeWidth={1.4} />
            </button>
            <button className="icon-button bag-trigger" type="button" onClick={() => setCartOpen(true)} aria-label={`سبد خرید، ${cartCount} محصول`}>
              <ShoppingBag size={24} strokeWidth={1.4} />
              {cartCount > 0 && <span className="bag-count">{cartCount}</span>}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {searchOpen && (
            <motion.div className="search-panel" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="page-container search-panel-inner" dir="rtl">
                <div className="search-field">
                  <Search size={21} strokeWidth={1.5} />
                  <input autoFocus type="search" placeholder="جستجو در محصولات نوا..." value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} aria-label="عبارت جستجو" />
                  <button className="icon-button" type="button" onClick={() => setSearchOpen(false)} aria-label="بستن جستجو"><X size={19} /></button>
                </div>
                <div className="search-results">
                  {searchResults.slice(0, 4).map((product) => (
                    <button key={product.id} type="button" className="search-result" onClick={() => openProduct(product)}>
                      <img src={product.image} alt="" />
                      <span>{product.name}<small>{formatPrice(product.price)} تومان</small></span>
                      <ArrowLeft size={16} strokeWidth={1.4} />
                    </button>
                  ))}
                  {searchResults.length === 0 && <p className="empty-search">محصولی با این نام پیدا نشد.</p>}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main>
        <section className={`hero ${currentHero.darkText ? "hero--dark-text" : ""}`} aria-label="کالکشن نوا گلد">
          <AnimatePresence initial={false}>
            <motion.img
              className="hero-photo"
              key={currentHero.image}
              src={currentHero.image}
              alt=""
              aria-hidden="true"
              style={{ objectPosition: currentHero.position }}
              initial={{ opacity: 0, scale: 1.025 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.85, ease: "easeInOut" }}
              fetchPriority={heroIndex === 0 ? "high" : "auto"}
            />
          </AnimatePresence>
          <div className="hero-shade" />
          <div className="page-container hero-inner">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                className="hero-copy"
                key={heroIndex}
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                dir="ltr"
              >
                <p className="eyebrow hero-eyebrow">PREMIUM GOLD JEWELRY</p>
                <h1>{currentHero.title[0]}<br />{currentHero.title[1]}</h1>
                <p className="hero-persian" dir="rtl">{currentHero.description}</p>
                <a className="gold-button" href="#categories">
                  <span>مشاهده کالکشن</span>
                  <ArrowRight size={22} strokeWidth={1.2} />
                </a>
              </motion.div>
            </AnimatePresence>
            <div className="hero-bottom">
              <div className="hero-pagination" aria-label="انتخاب اسلاید">
                {heroSlides.map((_, index) => (
                  <button key={index} className={index === heroIndex ? "is-active" : ""} type="button" onClick={() => setHeroIndex(index)} aria-label={`اسلاید ${index + 1}`} aria-current={index === heroIndex ? "true" : undefined}>
                    {String(index + 1).padStart(2, "0")}
                  </button>
                ))}
                <span className="pagination-line" />
              </div>
              <div className="hero-arrows">
                <button type="button" onClick={() => setHeroIndex((heroIndex - 1 + heroSlides.length) % heroSlides.length)} aria-label="اسلاید قبلی"><ArrowLeft size={23} strokeWidth={1.25} /></button>
                <button type="button" onClick={() => setHeroIndex((heroIndex + 1) % heroSlides.length)} aria-label="اسلاید بعدی"><ArrowRight size={23} strokeWidth={1.25} /></button>
              </div>
            </div>
          </div>
        </section>

        <section className="benefits" aria-label="مزایای نوا گلد">
          <div className="page-container benefits-grid" dir="rtl">
            <div className="benefit"><Gem size={39} strokeWidth={1.1} /><p><strong>تخصصی انگشتر طلا</strong><span>مطابق با سلیقه شما</span></p></div>
            <div className="benefit"><ShieldCheck size={39} strokeWidth={1.1} /><p><strong>ارسال امن</strong><span>به سراسر کشور</span></p></div>
            <div className="benefit"><PackageCheck size={39} strokeWidth={1.1} /><p><strong>ارسال عمده</strong><span>با شرایط ویژه</span></p></div>
            <div className="benefit"><Diamond size={39} strokeWidth={1.1} /><p><strong>طلای ۱۸ عیار</strong><span>استاندارد جهانی</span></p></div>
          </div>
        </section>

        <section className="categories-section" id="categories" aria-labelledby="categories-title">
          <div className="page-container">
            <Reveal className="section-heading">
              <h2 id="categories-title">دسته بندی ها</h2>
              <button className="view-link" type="button" onClick={() => selectCategory(null, true)}><span>مشاهده همه</span><ArrowRight size={19} strokeWidth={1.3} /></button>
            </Reveal>
            <div className="categories-grid" dir="rtl">
              {categories.map((category, index) => (
                <motion.a
                  key={category.id}
                  href="#products"
                  className="category-tile"
                  onClick={(event) => { event.preventDefault(); selectCategory(category.id); }}
                  initial={{ opacity: 0, y: 25 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{ duration: 0.65, delay: index * 0.065, ease: [0.22, 1, 0.36, 1] }}
                  aria-label={`مشاهده ${category.name}`}
                >
                  <img src={category.image} alt="" loading="lazy" style={{ objectPosition: category.position || "center" }} />
                  <div className="category-tile-content"><span>{category.name}</span><ArrowRight size={24} strokeWidth={1.1} /></div>
                </motion.a>
              ))}
            </div>
          </div>
        </section>

        <section className="collection-banner" id="collection" aria-label="کالکشن جدید نوا">
          <AnimatePresence initial={false}>
            <motion.img key={currentCollection.image} className="collection-photo" src={currentCollection.image} alt="" aria-hidden="true" initial={{ opacity: 0, scale: 1.03 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.75 }} loading="lazy" />
          </AnimatePresence>
          <div className="collection-shade" />
          <div className="page-container collection-inner">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div key={collectionIndex} className="collection-copy" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.5 }}>
                <p className="eyebrow">{currentCollection.eyebrow}</p>
                <h2 dir="rtl">{currentCollection.title}</h2>
                <p className="collection-description" dir="rtl">{currentCollection.description}</p>
                <button className="gold-button" type="button" onClick={() => selectCategory(collectionIndex === 0 ? "ring" : null, collectionIndex !== 0)}><span>مشاهده محصولات</span><ArrowRight size={21} strokeWidth={1.2} /></button>
              </motion.div>
            </AnimatePresence>
            <div className="collection-controls">
              <button type="button" onClick={() => setCollectionIndex((collectionIndex - 1 + collectionSlides.length) % collectionSlides.length)} aria-label="کالکشن قبلی"><ArrowLeft size={19} strokeWidth={1.3} /></button>
              <button type="button" onClick={() => setCollectionIndex((collectionIndex + 1) % collectionSlides.length)} aria-label="کالکشن بعدی"><ArrowRight size={19} strokeWidth={1.3} /></button>
              <span />
            </div>
          </div>
        </section>

        <section className="products-section" id="products" aria-labelledby="products-title">
          <div className="page-container">
            <Reveal className="section-heading">
              <h2 id="products-title">{selectedCategory ? categories.find((category) => category.id === selectedCategory)?.name : "محصولات منتخب"}</h2>
              <button className="view-link" type="button" onClick={() => { if (selectedCategory) selectCategory(null, true); else setShowAllProducts((value) => !value); }}>
                <span>{selectedCategory ? "همه محصولات" : showAllProducts ? "نمایش کمتر" : "مشاهده همه"}</span><ArrowRight size={19} strokeWidth={1.3} />
              </button>
            </Reveal>
            <div className="products-grid" dir="rtl">
              {visibleProducts.map((product, index) => (
                <motion.article
                  className="product"
                  key={product.id}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.12 }}
                  transition={{ duration: 0.58, delay: index * 0.07 }}
                >
                  <div className="product-image-wrap">
                    <button className="product-image-button" type="button" onClick={() => openProduct(product)} aria-label={`جزئیات ${product.name}`}>
                      <img src={product.image} alt={product.name} loading="lazy" />
                    </button>
                    {product.new && <span className="product-badge">جدید</span>}
                    <button className={`favorite-button ${favorites.includes(product.id) ? "is-favorite" : ""}`} type="button" onClick={() => toggleFavorite(product.id)} aria-label={favorites.includes(product.id) ? `حذف ${product.name} از علاقه مندی ها` : `افزودن ${product.name} به علاقه مندی ها`} aria-pressed={favorites.includes(product.id)}>
                      <Heart size={20} strokeWidth={1.45} fill={favorites.includes(product.id) ? "currentColor" : "none"} />
                    </button>
                  </div>
                  <button className="product-name" type="button" onClick={() => openProduct(product)}>{product.name}</button>
                  <p className="product-details" dir="ltr"><span>{product.weight}</span><i /><span>18K</span><i /><span>اجرت</span><i /><span>{product.making}</span></p>
                  <p className="product-price"><strong>{formatPrice(product.price)}</strong> تومان</p>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section className="brand-story" id="about" aria-labelledby="story-title">
          <img className="story-photo" src="/images/dark-ring.jpg" alt="" loading="lazy" />
          <div className="story-shade" />
          <div className="page-container story-inner">
            <Reveal className="story-copy">
              <h2 id="story-title">More than gold.</h2>
              <p className="story-lead" dir="rtl">بیش از طلا، یک تجربه ارزشمند.</p>
              <p className="story-description" dir="rtl">ما در نوا گلد، از کنار هم گذاشتن هنر، کیفیت و زیبایی، تجربه ای ماندگار برای همراهان و طلافروشان می سازیم.</p>
              <button className="story-link" type="button" onClick={() => setStoryOpen(true)}><span className="play-circle"><Play size={13} fill="currentColor" strokeWidth={1.2} /></span><span>درباره ما</span></button>
            </Reveal>
            <Reveal className="story-numbers" delay={0.15}>
              <div><strong>500<span>+</span></strong><span>مدل فعال</span></div>
              <div><strong>18K</strong><span>استاندارد طلا</span></div>
              <div><strong>24/7</strong><span>پشتیبانی</span></div>
            </Reveal>
          </div>
        </section>

        <section className="journal-section" id="journal" aria-labelledby="journal-title">
          <div className="page-container">
            <Reveal className="section-heading">
              <h2 id="journal-title">مجله نوا</h2>
              <button className="view-link" type="button" onClick={() => setShowAllArticles((value) => !value)}><span>{showAllArticles ? "نمایش کمتر" : "مشاهده همه"}</span><ArrowRight size={19} strokeWidth={1.3} /></button>
            </Reveal>
            <div className="journal-grid" dir="rtl">
              {articles.slice(0, showAllArticles ? 6 : 3).map((article, index) => (
                <motion.article className="journal-item" key={article.id} initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.1 }} transition={{ duration: 0.62, delay: (index % 3) * 0.09 }}>
                  <button className="journal-image" type="button" onClick={() => setActiveArticle(article)} aria-label={`خواندن ${article.title}`}><img src={article.image} alt="" loading="lazy" /></button>
                  <p className="journal-date">{article.date}</p>
                  <button className="journal-title" type="button" onClick={() => setActiveArticle(article)}>{article.title}</button>
                  <div className="journal-bottom"><span>{article.category}</span><button type="button" onClick={() => setActiveArticle(article)} aria-label={`خواندن ${article.title}`}><ArrowRight size={20} strokeWidth={1.25} /></button></div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section className="newsletter" id="newsletter" aria-labelledby="newsletter-title">
          <div className="newsletter-art" aria-hidden="true" />
          <div className="page-container newsletter-inner">
            <div className="newsletter-main">
              <h2 id="newsletter-title">Stay close to gold.</h2>
              <p dir="rtl">جدیدترین کالکشن ها و محصولات جدید را زودتر ببینید.</p>
              {newsletterSuccess ? (
                <p className="newsletter-confirmation"><Check size={18} /> ایمیل شما در این مرورگر ذخیره شد. از همراهی شما سپاسگزاریم.</p>
              ) : (
                <form className="newsletter-form" onSubmit={(event) => subscribe(event, "main")}>
                  <input dir="rtl" type="email" required placeholder="آدرس ایمیل خود را وارد کنید" aria-label="آدرس ایمیل" value={newsletterEmail} onChange={(event) => setNewsletterEmail(event.target.value)} />
                  <button type="submit">عضویت</button>
                </form>
              )}
            </div>
            <div className="newsletter-social" dir="rtl">
              <p>با ما در ارتباط باشید</p>
              <div className="social-links">
                <a href="https://www.instagram.com/" target="_blank" rel="noreferrer" aria-label="اینستاگرام"><Camera size={20} strokeWidth={1.4} /></a>
                <a href="https://telegram.org/" target="_blank" rel="noreferrer" aria-label="تلگرام"><Send size={19} strokeWidth={1.4} /></a>
                <a href="https://www.whatsapp.com/" target="_blank" rel="noreferrer" aria-label="واتساپ"><MessageCircle size={20} strokeWidth={1.4} /></a>
                <a href="mailto:hello@novagold.com" aria-label="ایمیل"><Mail size={20} strokeWidth={1.4} /></a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="page-container footer-top">
          <div className="footer-brand-block">
            <Brand inverse />
            <p dir="rtl">طلا و جواهر ارزشمند،<br />برای ویترین های مدرن</p>
          </div>
          <div className="footer-column" dir="rtl">
            <h3>محصولات</h3>
            {categories.map((category) => <button type="button" key={category.id} onClick={() => selectCategory(category.id)}>{category.name}</button>)}
          </div>
          <div className="footer-column" dir="rtl">
            <h3>راهنما</h3>
            <a href="#products">خرید عمده</a>
            <a href="#about">ارسال و تحویل</a>
            <a href="#about">ضمانت اصالت</a>
            <a href="mailto:hello@novagold.com">سوالات متداول</a>
          </div>
          <div className="footer-column" dir="rtl">
            <h3>درباره ما</h3>
            <button type="button" onClick={() => setStoryOpen(true)}>درباره نوا گلد</button>
            <a href="#journal">مجله</a>
            <a href="#newsletter">تماس با ما</a>
          </div>
          <div className="footer-signup" dir="rtl">
            <h3>عضویت در خبرنامه</h3>
            {footerSuccess ? <p className="footer-success"><Check size={14} /> ایمیل شما ذخیره شد.</p> : (
              <form className="footer-form" onSubmit={(event) => subscribe(event, "footer")}>
                <button type="submit" aria-label="عضویت در خبرنامه"><ArrowRight size={20} strokeWidth={1.25} /></button>
                <input type="email" required placeholder="ایمیل خود را وارد نمایید" aria-label="ایمیل خبرنامه" value={footerEmail} onChange={(event) => setFooterEmail(event.target.value)} />
              </form>
            )}
            <div className="footer-social">
              <a href="https://www.instagram.com/" target="_blank" rel="noreferrer" aria-label="اینستاگرام"><Camera size={17} strokeWidth={1.4} /></a>
              <a href="https://telegram.org/" target="_blank" rel="noreferrer" aria-label="تلگرام"><Send size={17} strokeWidth={1.4} /></a>
              <a href="https://www.whatsapp.com/" target="_blank" rel="noreferrer" aria-label="واتساپ"><MessageCircle size={17} strokeWidth={1.4} /></a>
              <a href="mailto:hello@novagold.com" aria-label="ایمیل"><Mail size={17} strokeWidth={1.4} /></a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="page-container footer-bottom-inner">
            <small dir="ltr">© 2025 NOVA GOLD. All rights reserved.</small>
            <div dir="rtl"><a href="mailto:hello@novagold.com?subject=Privacy">حریم خصوصی</a><span /> <a href="mailto:hello@novagold.com?subject=Terms">قوانین و مقررات</a></div>
          </div>
        </div>
      </footer>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div className="screen-overlay drawer-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(event) => { if (event.target === event.currentTarget) setMobileMenuOpen(false); }}>
            <motion.aside className="side-drawer mobile-drawer" role="dialog" aria-modal="true" aria-label="منوی اصلی" initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "tween", duration: 0.32 }} dir="rtl">
              <div className="drawer-heading"><Brand onClick={() => setMobileMenuOpen(false)} /><button className="icon-button" type="button" onClick={() => setMobileMenuOpen(false)} aria-label="بستن منو"><X size={23} /></button></div>
              <nav className="mobile-nav" aria-label="منوی موبایل">
                {[
                  { text: "خانه", href: "#top" }, { text: "محصولات", href: "#products" }, { text: "دسته بندی ها", href: "#categories" },
                  { text: "کالکشن ها", href: "#collection" }, { text: "مجله نوا", href: "#journal" }, { text: "درباره ما", href: "#about" }, { text: "تماس با ما", href: "#newsletter" },
                ].map((item) => <a key={item.href} href={item.href} onClick={() => setMobileMenuOpen(false)}>{item.text}<ArrowLeft size={17} strokeWidth={1.3} /></a>)}
                <button type="button" onClick={() => { setMobileMenuOpen(false); setAccountOpen(true); }}>حساب کاربری<ArrowLeft size={17} strokeWidth={1.3} /></button>
              </nav>
              <p className="mobile-drawer-note">NOVA GOLD · PREMIUM GOLD JEWELRY</p>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {cartOpen && (
          <motion.div className="screen-overlay drawer-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(event) => { if (event.target === event.currentTarget) setCartOpen(false); }}>
            <motion.aside className="side-drawer cart-drawer" role="dialog" aria-modal="true" aria-label="سبد خرید" initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "tween", duration: 0.32 }} dir="rtl">
              <div className="drawer-heading"><div><span className="drawer-eyebrow">NOVA GOLD</span><h2>سبد خرید <small>({cartCount})</small></h2></div><button className="icon-button" type="button" onClick={() => setCartOpen(false)} aria-label="بستن سبد خرید"><X size={23} /></button></div>
              {cart.length === 0 ? (
                <div className="cart-empty"><ShoppingBag size={45} strokeWidth={1} /><h3>سبد خرید شما خالی است.</h3><p>مجموعه نوا را ببینید و قطعه محبوب خود را انتخاب کنید.</p><button className="gold-button" type="button" onClick={() => { setCartOpen(false); document.getElementById("products")?.scrollIntoView({ behavior: "smooth" }); }}>مشاهده محصولات <ArrowRight size={19} /></button></div>
              ) : (
                <>
                  <div className="cart-items">
                    {cart.map((item) => {
                      const product = products.find((entry) => entry.id === item.id);
                      if (!product) return null;
                      return <div className="cart-item" key={item.id}>
                        <img src={product.image} alt="" />
                        <div className="cart-item-copy"><strong>{product.name}</strong><span>طلای ۱۸ عیار</span><b>{formatPrice(product.price)} تومان</b><div className="quantity-control"><button type="button" onClick={() => updateCartQuantity(item.id, -1)} aria-label={`کم کردن ${product.name}`}><Minus size={14} /></button><span>{item.quantity}</span><button type="button" onClick={() => updateCartQuantity(item.id, 1)} aria-label={`افزودن ${product.name}`}><Plus size={14} /></button></div></div>
                        <button className="cart-remove" type="button" onClick={() => setCart((current) => current.filter((entry) => entry.id !== item.id))} aria-label={`حذف ${product.name}`}><Trash2 size={17} strokeWidth={1.4} /></button>
                      </div>;
                    })}
                  </div>
                  <div className="cart-summary"><div><span>جمع تقریبی</span><strong>{formatPrice(cartTotal)} تومان</strong></div><p>قیمت نهایی با توجه به نرخ روز طلا تایید می شود.</p><button className="gold-button" type="button" onClick={checkoutByEmail}><span>درخواست سفارش</span><ArrowRight size={19} /></button><button className="continue-shopping" type="button" onClick={() => setCartOpen(false)}>ادامه خرید</button></div>
                </>
              )}
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {activeProduct && (
          <Dialog key="product" onClose={() => setActiveProduct(null)} label={`جزئیات ${activeProduct.name}`} className="product-dialog">
            <div className="product-dialog-image"><img src={activeProduct.image} alt={activeProduct.name} /></div>
            <div className="product-dialog-content" dir="rtl">
              <p className="dialog-eyebrow">NOVA GOLD / 18K GOLD</p>
              <h2>{activeProduct.name}</h2>
              <p className="dialog-description">{activeProduct.description}</p>
              <div className="dialog-specs"><span>وزن تقریبی: {activeProduct.weight}</span><span>عیار: ۱۸</span><span>اجرت ساخت: {activeProduct.making}</span></div>
              <p className="dialog-price">{formatPrice(activeProduct.price)} <span>تومان</span></p>
              <div className="product-dialog-actions"><div className="quantity-control"><button type="button" onClick={() => setProductQuantity(Math.max(1, productQuantity - 1))} aria-label="کاهش تعداد"><Minus size={16} /></button><span>{productQuantity}</span><button type="button" onClick={() => setProductQuantity(productQuantity + 1)} aria-label="افزایش تعداد"><Plus size={16} /></button></div><button className="gold-button" type="button" onClick={() => addToCart(activeProduct.id, productQuantity)}><span>افزودن به سبد خرید</span><ShoppingBag size={18} /></button></div>
              <p className="dialog-footnote"><ShieldCheck size={17} strokeWidth={1.3} /> تضمین اصالت و ارسال امن به سراسر کشور</p>
            </div>
          </Dialog>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {activeArticle && (
          <Dialog key="article" onClose={() => setActiveArticle(null)} label={activeArticle.title} className="article-dialog">
            <img className="article-dialog-image" src={activeArticle.image} alt="" />
            <div className="article-dialog-copy" dir="rtl"><p className="dialog-eyebrow">مجله نوا / {activeArticle.category}</p><h2>{activeArticle.title}</h2><span className="article-dialog-date">{activeArticle.date}</span><p>{activeArticle.intro}</p><p>در نوا گلد باور داریم انتخاب آگاهانه، زیبایی هر قطعه را دوچندان می کند. شناخت کیفیت ساخت، توجه به جزئیات و انتخاب متناسب با سلیقه، مسیر یک خرید ماندگار را می سازد.</p></div>
          </Dialog>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {storyOpen && (
          <Dialog key="story" onClose={() => setStoryOpen(false)} label="درباره نوا گلد" className="story-dialog">
            <img src="/images/hero-still-life.jpg" alt="زیورآلات طلای نوا روی سنگ روشن" />
            <div dir="rtl"><p className="dialog-eyebrow">THE NOVA STORY</p><h2>بیش از طلا.</h2><p>نوا گلد از عشق به طراحی دقیق و زیبایی ماندگار شکل گرفته است. هر قطعه با توجه به جزئیات، کیفیت ساخت و سلیقه امروز انتخاب می شود تا در لحظه های شما بدرخشد.</p><p>از انتخاب یک هدیه شخصی تا تکمیل ویترین کسب و کارتان، همراه شما هستیم.</p><button className="gold-button" type="button" onClick={() => { setStoryOpen(false); document.getElementById("products")?.scrollIntoView({ behavior: "smooth" }); }}><span>دیدن مجموعه</span><ArrowRight size={18} /></button></div>
          </Dialog>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {accountOpen && (
          <Dialog key="account" onClose={() => setAccountOpen(false)} label="حساب کاربری" className="account-dialog">
            <div dir="rtl"><p className="dialog-eyebrow">NOVA GOLD</p><h2>حساب کاربری</h2><p>برای شخصی سازی تجربه خرید، مشخصات خود را در این مرورگر ذخیره کنید.</p><form onSubmit={saveProfile}><label>نام شما<input type="text" required placeholder="نام و نام خانوادگی" value={profileName} onChange={(event) => setProfileName(event.target.value)} /></label><label>ایمیل<input type="email" required placeholder="example@email.com" value={profileEmail} onChange={(event) => setProfileEmail(event.target.value)} /></label><button className="gold-button" type="submit"><span>ذخیره مشخصات</span><ArrowRight size={18} /></button></form>{profile.name && <span className="account-current">پروفایل فعلی: {profile.name}</span>}</div>
          </Dialog>
        )}
      </AnimatePresence>

      <AnimatePresence>{toast && <motion.div className="toast" role="status" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}><Check size={17} />{toast}</motion.div>}</AnimatePresence>
    </div>
  );
}